#include "sim/event_loop.h"
// header-only implementation; this TU exists to please some build systems.
