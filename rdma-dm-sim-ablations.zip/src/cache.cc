#include "sim/cache.h"
// (All inline in header for this simple LRU.)
